# ledcontrol

Raspberry Pi 5 onboard LED control library for Python.

## Install

```bash
pip install . --break-system-packages
```

## Quick start

```python
import ledcontrol

# Run once after every reboot
ledcontrol.setup()

# Green LED (ACT)
ledcontrol.green.on()
ledcontrol.green.off()
ledcontrol.green.heartbeat()

# Red LED (PWR)
ledcontrol.red.on()
ledcontrol.red.off()
ledcontrol.red.heartbeat()

# Both at once
ledcontrol.green.on()
ledcontrol.red.on()

# Turn everything off
ledcontrol.off()
```

> Scripts that write to `/sys/class/leds/` need root — run with `sudo python3 yourscript.py`.

## LED reference (Pi 5)

| Object | sysfs path | Colour |
|--------|-----------|--------|
| `ledcontrol.green` | `/sys/class/leds/ACT` | Green |
| `ledcontrol.red` | `/sys/class/leds/PWR` | Red |
