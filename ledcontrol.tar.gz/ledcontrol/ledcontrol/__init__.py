"""
ledcontrol — Raspberry Pi 5 onboard LED control

Usage
-----
    import ledcontrol

    ledcontrol.setup()          # run once after every reboot

    ledcontrol.green.on()
    ledcontrol.green.off()
    ledcontrol.green.heartbeat()

    ledcontrol.red.on()
    ledcontrol.red.off()
    ledcontrol.red.heartbeat()

    ledcontrol.off()            # turn everything off
"""

__version__ = "1.0.0"
__author__  = "user17726"
__all__     = ["green", "red", "setup", "off"]

from ._leds import GreenLED, RedLED
from ._core import LED_ACT, LED_PWR, LED_DEFAULT, trigger, brightness

# ─── Module-level LED objects ─────────────────────────────────────────────────

green = GreenLED()
red   = RedLED()


# ─── Module-level functions ───────────────────────────────────────────────────

def setup() -> None:
    """Disable the default-on LED.

    Must be called once after every reboot, otherwise the default-on LED
    adds a green component to all states and colours will be wrong.

    Example
    -------
        import ledcontrol
        ledcontrol.setup()
    """
    trigger(LED_DEFAULT, "none")
    trigger(LED_ACT, "none")
    brightness(LED_DEFAULT, 0)
    print("ledcontrol: setup done.")


def off() -> None:
    """Turn all onboard LEDs off.

    Example
    -------
        import ledcontrol
        ledcontrol.off()
    """
    trigger(LED_ACT, "none")
    trigger(LED_PWR, "none")
    brightness(LED_ACT, 255)        # ACT inverted: 255 = off
    brightness(LED_PWR, 0)
    brightness(LED_DEFAULT, 0)
