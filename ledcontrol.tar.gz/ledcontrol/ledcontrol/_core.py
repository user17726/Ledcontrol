"""Internal sysfs helpers — not part of the public API."""

import os
import sys

LED_ACT     = "/sys/class/leds/ACT"
LED_PWR     = "/sys/class/leds/PWR"
LED_DEFAULT = "/sys/class/leds/default-on"


def write(path: str, value: str) -> None:
    try:
        with open(path, "w") as f:
            f.write(value + "\n")
    except PermissionError:
        print(f"ledcontrol: permission denied — {path}", file=sys.stderr)
        print("ledcontrol: run your script with sudo.", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(f"ledcontrol: LED path not found — {path}", file=sys.stderr)
        print("ledcontrol: is this a Raspberry Pi 5?", file=sys.stderr)
        sys.exit(1)


def trigger(led: str, value: str) -> None:
    write(os.path.join(led, "trigger"), value)


def brightness(led: str, value: int) -> None:
    write(os.path.join(led, "brightness"), str(value))
