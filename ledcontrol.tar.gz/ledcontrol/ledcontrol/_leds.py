"""LED classes — GreenLED and RedLED with on/off/heartbeat methods."""

from . _core import LED_ACT, LED_PWR, LED_DEFAULT, trigger, brightness


class GreenLED:
    """Controls the green ACT LED on the Raspberry Pi 5.

    Note: ACT is hardware-inverted (brightness 0 = ON, 255 = OFF).
    """

    def on(self) -> None:
        """Turn the green LED on."""
        trigger(LED_ACT, "none")
        brightness(LED_ACT, 0)      # inverted: 0 = on

    def off(self) -> None:
        """Turn the green LED off."""
        trigger(LED_ACT, "none")
        brightness(LED_ACT, 255)    # inverted: 255 = off

    def heartbeat(self) -> None:
        """Set the green LED to heartbeat blink."""
        trigger(LED_ACT, "heartbeat")

    def __repr__(self) -> str:
        return "GreenLED(ACT)"


class RedLED:
    """Controls the red PWR LED on the Raspberry Pi 5."""

    def on(self) -> None:
        """Turn the red LED on."""
        trigger(LED_PWR, "none")
        brightness(LED_DEFAULT, 0)  # suppress green bleed from default-on
        brightness(LED_PWR, 255)

    def off(self) -> None:
        """Turn the red LED off."""
        trigger(LED_PWR, "none")
        brightness(LED_PWR, 0)

    def heartbeat(self) -> None:
        """Set the red LED to heartbeat blink."""
        brightness(LED_DEFAULT, 0)
        trigger(LED_PWR, "heartbeat")

    def __repr__(self) -> str:
        return "RedLED(PWR)"
