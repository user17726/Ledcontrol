#!/bin/bash
#led_eth_control_script/key=fwfz9wz9vsv
cat << 'EOF' > /tmp/eth_led.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/mii.h>
#include <linux/sockios.h>

int main(int argc, char *argv[]) {
    if (argc < 2) return 1;
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    struct ifreq ifr;
    strncpy(ifr.ifr_name, "eth0", IFNAMSIZ);
    struct mii_ioctl_data *mii = (struct mii_ioctl_data *)&ifr.ifr_data;
    mii->phy_id = 1;
    mii->reg_num = 0x17;
    mii->val_in = 0x0f04;
    ioctl(fd, SIOCSMIIREG, &ifr);
    mii->reg_num = 0x15;
    mii->val_in = (int)strtol(argv[1], NULL, 16);
    ioctl(fd, SIOCSMIIREG, &ifr);
    close(fd);
    return 0;
}
EOF

gcc -o /tmp/eth_led /tmp/eth_led.c
rm /tmp/eth_led.c

case "$1" in
    -g)  /tmp/eth_led 0x041 ;;
    -y)  /tmp/eth_led 0x054 ;;
    -o)  /tmp/eth_led 0x044 ;;
    -b)  /tmp/eth_led 0x055 ;;
    -gb) /tmp/eth_led 0x046 ;;
    -yg) /tmp/eth_led 0x061 ;;
    -yb) /tmp/eth_led 0x064 ;;
    -gy) /tmp/eth_led 0x056 ;;
    -ab) /tmp/eth_led 0x066 ;;
    *)   echo "Usage: $0 <flag>"; rm /tmp/eth_led; exit 1 ;;
esac

rm /tmp/eth_led
